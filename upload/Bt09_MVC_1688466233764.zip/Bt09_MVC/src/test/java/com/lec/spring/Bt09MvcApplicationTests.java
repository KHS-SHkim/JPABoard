package com.lec.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bt09MvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
